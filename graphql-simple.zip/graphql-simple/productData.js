// src/data/productData.js
const products = [
  { id: '1', name: 'Laptop', price: 78000 },
  { id: '2', name: 'Smartphone', price: 35000 },
  { id: '3', name: 'Tablet', price: 25000 },
];

const getProducts = () => products;

const getProductById = (id) => products.find(product => product.id === id);

module.exports = { getProducts, getProductById };
